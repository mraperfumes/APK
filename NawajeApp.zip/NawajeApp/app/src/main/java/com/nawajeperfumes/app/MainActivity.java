package com.nawajeperfumes.app;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private static final String SITE_HOST = "nawajeperfumes.name.ng";
    private static final String HOME_URL = "https://nawajeperfumes.name.ng/";
    private static final String WHATSAPP_URL =
            "https://wa.me/2347062359015?text=" + Uri.encode("Hello Nawaje Perfumes, I would like to make an enquiry.");

    private WebView webView;
    private SwipeRefreshLayout swipe;
    private ProgressBar pageProgress;
    private View loadingOverlay, errorLayout, findBar, offlineBanner;
    private ImageView loadingLogo;
    private EditText findInput;
    private TextView findCount, errorMessage;
    private BottomNavigationView nav;

    private ObjectAnimator pulse;
    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback networkCallback;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private boolean hasError = false;
    private String pendingSection = null;
    private long lastBackPress = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        bindViews();
        setupSystemBars();
        setupWebView();
        setupNavigation();
        setupSearch();
        setupButtons();
        setupBackHandling();
        startLoadingAnimation();

        String start = HOME_URL;
        Uri data = getIntent() != null ? getIntent().getData() : null;
        if (data != null && isInternal(data)) start = data.toString();
        loadUrl(start);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        Uri data = intent.getData();
        if (data != null && isInternal(data)) loadUrl(data.toString());
    }

    // ---------------------------------------------------------------- setup

    private void bindViews() {
        webView = findViewById(R.id.webview);
        swipe = findViewById(R.id.swipe_refresh);
        pageProgress = findViewById(R.id.page_progress);
        loadingOverlay = findViewById(R.id.loading_overlay);
        loadingLogo = findViewById(R.id.loading_logo);
        errorLayout = findViewById(R.id.error_layout);
        errorMessage = findViewById(R.id.error_message);
        findBar = findViewById(R.id.find_bar);
        findInput = findViewById(R.id.find_input);
        findCount = findViewById(R.id.find_count);
        offlineBanner = findViewById(R.id.offline_banner);
        nav = findViewById(R.id.bottom_nav);
    }

    private void setupSystemBars() {
        WindowInsetsControllerCompat c =
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        c.setAppearanceLightStatusBars(false);
        c.setAppearanceLightNavigationBars(true);

        View header = findViewById(R.id.header_container);
        ViewCompat.setOnApplyWindowInsetsListener(header, (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.statusBars() | WindowInsetsCompat.Type.displayCutout());
            v.setPadding(0, bars.top, 0, 0);
            return insets;
        });
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setAllowFileAccess(false);
        s.setUserAgentString(s.getUserAgentString() + " NawajePerfumesApp/1.0");
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (isInternal(uri)) return false;
                if (!request.isForMainFrame()) return false;
                openExternal(uri);
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                hasError = false;
                pageProgress.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageProgress.setVisibility(View.GONE);
                swipe.setRefreshing(false);
                if (!hasError) {
                    errorLayout.setVisibility(View.GONE);
                    hideLoadingOverlay();
                    if (pendingSection != null) {
                        final String section = pendingSection;
                        pendingSection = null;
                        handler.postDelayed(() -> runSectionJs(section), 700);
                    }
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) showError();
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request,
                                            WebResourceResponse errorResponse) {
                if (request.isForMainFrame() && errorResponse.getStatusCode() >= 400) showError();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                pageProgress.setProgress(newProgress);
                if (newProgress >= 100) pageProgress.setVisibility(View.GONE);
            }
        });

        swipe.setColorSchemeResources(R.color.burgundy, R.color.gold);
        swipe.setOnChildScrollUpCallback((parent, child) -> webView.getScrollY() > 0);
        swipe.setOnRefreshListener(this::refreshPage);
    }

    private void setupNavigation() {
        nav.setOnItemSelectedListener(item -> {
            handleNav(item.getItemId());
            return true;
        });
        nav.setOnItemReselectedListener(item -> handleNav(item.getItemId()));
    }

    private void handleNav(int id) {
        if (id == R.id.nav_home) goToSection("home");
        else if (id == R.id.nav_shop) goToSection("shop");
        else if (id == R.id.nav_cart) goToSection("cart");
        else if (id == R.id.nav_about) goToSection("about");
        else if (id == R.id.nav_contact) goToSection("contact");
    }

    private void setupSearch() {
        findViewById(R.id.btn_search).setOnClickListener(v -> {
            if (findBar.getVisibility() == View.VISIBLE) closeFind();
            else openFind();
        });
        findViewById(R.id.find_close).setOnClickListener(v -> closeFind());
        findViewById(R.id.find_next).setOnClickListener(v -> webView.findNext(true));
        findViewById(R.id.find_prev).setOnClickListener(v -> webView.findNext(false));

        findInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override
            public void afterTextChanged(Editable s) {
                String q = s.toString().trim();
                if (q.isEmpty()) {
                    webView.clearMatches();
                    findCount.setText("");
                } else {
                    webView.findAllAsync(q);
                }
            }
        });
        findInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                hideKeyboard();
                webView.findNext(true);
                return true;
            }
            return false;
        });
        webView.setFindListener((active, count, done) -> {
            if (done) findCount.setText(count == 0 ? "0" : (active + 1) + "/" + count);
        });
    }

    private void setupButtons() {
        findViewById(R.id.btn_retry).setOnClickListener(v -> retry());
        findViewById(R.id.btn_error_whatsapp).setOnClickListener(v -> openExternal(Uri.parse(WHATSAPP_URL)));
        findViewById(R.id.fab_whatsapp).setOnClickListener(v -> openExternal(Uri.parse(WHATSAPP_URL)));
    }

    private void setupBackHandling() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (findBar.getVisibility() == View.VISIBLE) {
                    closeFind();
                    return;
                }
                if (!hasError && webView.canGoBack()) {
                    webView.goBack();
                    return;
                }
                long now = System.currentTimeMillis();
                if (now - lastBackPress < 2000) {
                    finish();
                } else {
                    lastBackPress = now;
                    Toast.makeText(MainActivity.this, R.string.press_back_again, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // ---------------------------------------------------------------- loading

    private void startLoadingAnimation() {
        pulse = ObjectAnimator.ofPropertyValuesHolder(loadingLogo,
                PropertyValuesHolder.ofFloat("scaleX", 1f, 1.1f),
                PropertyValuesHolder.ofFloat("scaleY", 1f, 1.1f));
        pulse.setDuration(900);
        pulse.setRepeatCount(ObjectAnimator.INFINITE);
        pulse.setRepeatMode(ObjectAnimator.REVERSE);
        pulse.start();
    }

    private void hideLoadingOverlay() {
        if (loadingOverlay.getVisibility() != View.VISIBLE) return;
        loadingOverlay.animate().alpha(0f).setDuration(300).withEndAction(() -> {
            loadingOverlay.setVisibility(View.GONE);
            loadingOverlay.setAlpha(1f);
            if (pulse != null) pulse.cancel();
        }).start();
    }

    private void loadUrl(String url) {
        hasError = false;
        errorLayout.setVisibility(View.GONE);
        webView.getSettings().setCacheMode(
                isOnline() ? WebSettings.LOAD_DEFAULT : WebSettings.LOAD_CACHE_ELSE_NETWORK);
        webView.loadUrl(url);
    }

    private void refreshPage() {
        String url = webView.getUrl();
        if (hasError || url == null || url.startsWith("about:") || !isInternal(Uri.parse(url))) {
            loadUrl(HOME_URL);
        } else {
            loadUrl(url);
        }
    }

    private void retry() {
        loadingOverlay.setAlpha(1f);
        loadingOverlay.setVisibility(View.VISIBLE);
        if (pulse != null && !pulse.isRunning()) pulse.start();
        errorLayout.setVisibility(View.GONE);
        refreshPage();
    }

    private void showError() {
        hasError = true;
        swipe.setRefreshing(false);
        pageProgress.setVisibility(View.GONE);
        loadingOverlay.setVisibility(View.GONE);
        if (pulse != null) pulse.cancel();
        errorMessage.setText(isOnline() ? R.string.error_generic : R.string.error_offline);
        errorLayout.setVisibility(View.VISIBLE);
    }

    // ---------------------------------------------------------------- sections / search

    private void goToSection(String section) {
        closeFind();
        String cur = webView.getUrl();
        if (hasError || cur == null || cur.startsWith("about:") || !isInternal(Uri.parse(cur))) {
            pendingSection = section;
            loadUrl(HOME_URL);
            return;
        }
        runSectionJs(section);
    }

    private void runSectionJs(String section) {
        String js;
        if (section.equals("home")) {
            js = "window.scrollTo({top:0,behavior:'smooth'});";
        } else if (section.equals("cart")) {
            js = "(function(){var b=document.querySelector('a[href=\"#cart\"],#cartBtn,.cart-btn');"
                    + "if(b){b.click();}else{location.hash='cart';}})();";
        } else {
            js = "(function(){var e=document.getElementById('" + section + "');"
                    + "if(e){e.scrollIntoView({behavior:'smooth',block:'start'});}"
                    + "else{location.hash='" + section + "';}})();";
        }
        webView.evaluateJavascript(js, null);
    }

    private void openFind() {
        findBar.setVisibility(View.VISIBLE);
        findInput.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(findInput, InputMethodManager.SHOW_IMPLICIT);
    }

    private void closeFind() {
        if (findBar.getVisibility() != View.VISIBLE) return;
        findBar.setVisibility(View.GONE);
        findInput.setText("");
        findCount.setText("");
        webView.clearMatches();
        hideKeyboard();
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(findInput.getWindowToken(), 0);
    }

    // ---------------------------------------------------------------- links

    private boolean isInternal(Uri uri) {
        String scheme = uri.getScheme();
        String host = uri.getHost();
        if (scheme == null || host == null) return false;
        if (!scheme.equals("https") && !scheme.equals("http")) return false;
        return host.equals(SITE_HOST) || host.endsWith("." + SITE_HOST);
    }

    private void openExternal(Uri uri) {
        try {
            Intent intent;
            if ("intent".equals(uri.getScheme())) {
                intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                intent.setComponent(null);
                intent.setSelector(null);
            } else {
                intent = new Intent(Intent.ACTION_VIEW, uri);
            }
            intent.addCategory(Intent.CATEGORY_BROWSABLE);
            startActivity(intent);
        } catch (ActivityNotFoundException | java.net.URISyntaxException | SecurityException e) {
            Toast.makeText(this, R.string.cannot_open, Toast.LENGTH_SHORT).show();
        }
    }

    // ---------------------------------------------------------------- connectivity

    private boolean isOnline() {
        if (cm == null) return true;
        Network n = cm.getActiveNetwork();
        if (n == null) return false;
        NetworkCapabilities caps = cm.getNetworkCapabilities(n);
        return caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
        offlineBanner.setVisibility(isOnline() ? View.GONE : View.VISIBLE);
        if (cm != null && networkCallback == null) {
            networkCallback = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network network) {
                    runOnUiThread(() -> {
                        offlineBanner.setVisibility(View.GONE);
                        if (hasError) retry();
                    });
                }

                @Override
                public void onLost(Network network) {
                    runOnUiThread(() ->
                            offlineBanner.setVisibility(isOnline() ? View.GONE : View.VISIBLE));
                }
            };
            try {
                cm.registerDefaultNetworkCallback(networkCallback);
            } catch (RuntimeException e) {
                networkCallback = null;
            }
        }
    }

    @Override
    protected void onPause() {
        if (cm != null && networkCallback != null) {
            try {
                cm.unregisterNetworkCallback(networkCallback);
            } catch (RuntimeException ignored) { }
            networkCallback = null;
        }
        webView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (pulse != null) pulse.cancel();
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
