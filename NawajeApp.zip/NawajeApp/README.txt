NAWAJE PERFUMES - Android app (native WebView wrapper for https://nawajeperfumes.name.ng/)

Package ID : com.nawajeperfumes.app
Min Android: 7.0 (API 24)   Target: API 35
Build tool : Gradle 8.9 + Android Gradle Plugin 8.7.3, Java 17

HOW TO BUILD FROM A PHONE (GitHub Actions, free)
1. Create a free account at github.com and a new PRIVATE repository.
2. In the repo tap Add file > Upload files, upload NawajeApp.zip (do NOT unzip it), then Commit.
3. Tap Add file > Create new file. Name it:  .github/workflows/build.yml
   Paste the workflow text (also saved in this project at .github/workflows/build.yml). Commit.
4. Open the Actions tab > "Build Nawaje APK" > wait for the green tick (about 4-6 minutes).
5. Open the finished run > Artifacts > Nawaje-Perfumes-APK. Download, unzip, install the .apk.

BUILD ON A COMPUTER
Open this folder in Android Studio, or run:  gradle assembleDebug

CHANGING THINGS
- Website URL        : MainActivity.java (HOME_URL, SITE_HOST)
- WhatsApp number    : MainActivity.java (WHATSAPP_URL)
- Colours            : app/src/main/res/values/colors.xml
- Version number     : app/build.gradle (versionCode / versionName)
- Splash image       : app/src/main/res/drawable-nodpi/splash_screen.jpg
- Icons              : app/src/main/res/mipmap-*/
- Play Store icon    : store/play_store_icon_512.png
